class AssociationType:
    COMPANY_TO_CONTACT = "company_to_contact"
    CONTACT_TO_DEAL = "contact_to_deal"
