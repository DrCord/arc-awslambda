# -*- coding: utf-8 -*-
"""Define the influxdb08 test package."""
